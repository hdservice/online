<?php
try{
    $database = 'hdservice';
    $host = 'localhost';
    $db_user = 'root';
    $db_pw = '';
    $charset = 'utf8';
    
    
    $db = new PDO( 'mysql:host=' . $host . ';dbname=' . $database . ';charset=' . $charset, $db_user, $db_pw );    
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    
	echo 'Data Base Connected Seccessfully!!';
    
}catch( exception $exception ){
    
	echo $exception ;
	echo $exception->getMassage() ;
	echo 'Data Base could not Connected!';
}


?>