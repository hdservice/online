<?php
require_once('dbconnect.php');

$name = $_POST['user_name'] ;
$mobile = $_POST['user_mobile'] ;
$email = $_POST['user_email'] ;
$userid = $_POST['user_id'] ;
$password = $_POST['user_password'] ;

$stmt = $db->prepare("INSERT INTO users ( name, mobile, email, userid, password ) VALUES (:name, :mobile, :email, :userid, :password ) ");
$stmt-> execute(array( ':name'=>$name, ':mobile'=>$mobile, ':email'=>$email, ':userid'=>$userid, ':password'=>$password )) ;

//echo 'Data Inserted Seccessfulluy!!!!';


header ('Location: ../admin.php?Submitted Seccessfully!!!')


?>