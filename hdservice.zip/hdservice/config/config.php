<?php
$HOSTNAME = $_SERVER['HTTP_HOST'];
$DIR = $_SERVER['DOCUMENT_ROOT'].'/hds/def/';
$DIR_HTML = $_SERVER['DOCUMENT_ROOT'].'/hds/def/html/';
$DIR_UPDATES = $_SERVER['DOCUMENT_ROOT'].'/hds/def/html/updates/';
$IMG_ROOT = $DIR .'images/';
$STYLE = $DIR.'styles/';
$JSCRIPT = $DIR.'js/';
?>