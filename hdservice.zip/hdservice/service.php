<?php
include 'styles/hmstyle.html';
include 'styles/allstyles.html';
//include 'js/jq.html';
include 'workpages/header.html';
include 'workpages/sidebar.html';
include 'workpages/service-main.html';
?>